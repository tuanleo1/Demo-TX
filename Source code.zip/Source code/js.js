function getchoice() {
    const choice = document.getElementById('choice').value
}
function play() {
    const x = Math.random(1,6)
    const y = Math.random(1,6)
    const z = Math.random(1,6)
    const total = x+y+z
    const win = choice=='tai' && total >= 11 || choice == 'xiu' && total <= 10
    const lose = choice=='tai' && total <= 10 || choice == 'xiu' && total >= 11 || x == y == z 
    if (win) {
        console.log(x, y, z)
        console.log('Bạn THắng')
    }
    if (lose) {
        console.log(x, y, z)
        console.log('Bạn Thua')
    }
}

