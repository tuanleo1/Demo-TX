let choice = ''
let balance = 1000

function getChoice(userChoice) {
    choice = userChoice
}

function play(event) {
    if (event) event.preventDefault()

    const bet = Number(document.getElementById("BetAmount").value)
    const x = Math.floor(Math.random() *6) + 1
    const y = Math.floor(Math.random() *6) + 1
    const z = Math.floor(Math.random() *6) + 1
    const total = x + y + z
    const win = (choice === 'tai' && total >= 11 || choice === 'xiu' && total <= 10)
    const triple = (x === y && y === z)

    const dice1 = document.getElementById("dice1")
    const dice2 = document.getElementById("dice2")
    const dice3 = document.getElementById("dice3")

    dice1.textContent = x
    dice2.textContent = y
    dice3.textContent = z

    dice1.classList.add("roll")
    dice2.classList.add("roll")
    dice3.classList.add("roll")

    setTimeout(()=>{
        dice1.classList.remove("roll")
        dice2.classList.remove("roll")
        dice3.classList.remove("roll")
    },600)

    let message = ""

    console.log('Xúc Xắc:', x, y, z)
    console.log('Tổng:',total)

    if (!bet || bet <= 0) {
        alert("Nhập tiền cược hợp lệ!")
        return
    }

    if (bet > balance) {
        alert("Không đủ tiền!")
        return
    }
    if (!choice) {
        alert("Bạn chưa chọn Tài hoặc Xỉu!")
        return
    }
    if (triple) {
        console.log('TRIPLE!!!')
        console.log('Bạn Thua❌')
        balance = balance - bet
        console.log(balance)
    }
    else if (win) {
        console.log('Bạn Thắng🎉')
        balance = balance + bet
        console.log(balance)
    }
    else {
        console.log('Bạn Thua❌')
        balance = balance - bet
        console.log(balance)
    }
    document.getElementById("balance").textContent = balance
    document.getElementById("result").textContent = 
        `Tổng: ${total} → ${message}`
}

